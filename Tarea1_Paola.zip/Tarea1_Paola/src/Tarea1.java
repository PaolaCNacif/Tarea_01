
import java.util.Scanner;

public class Tarea1 {
    
    public static void main(String []args){
        
    //Imprimir mis datos 
        System.out.println("Tarea 1\nPaola Castillo Nacif\nMatrícula: A01376654 ");
    //Preguntar
    Scanner teclado=new Scanner (System.in);
        System.out.println("Teclea tu día de nacimiento:");
    int dia=teclado.nextInt();
        System.out.println("Teclea tu mes de nacimiento:");
    int mes=teclado.nextInt();
        System.out.println("Teclea tu año de nacimiento:");
    int año=teclado.nextInt();
        teclado.nextLine();
        System.out.println("Teclea tu nombre:");
        String nombre=teclado.nextLine();
        
    // Convertir datos
    Fecha fechaN=new Fecha(dia, mes, año);
   
    //FrecuenciaCardiaca
    
    FrecuenciaCardiaca frecuenciaC = new FrecuenciaCardiaca(nombre,fechaN);
    
   
    //Imprimir datos del usuario
        String nombreF=frecuenciaC.getNombre();
        System.out.println("\nNombre:"+nombreF);
        System.out.println("Fecha de nacimiento:"+frecuenciaC.getFechaNacimiento());
        System.out.println("Edad:"+fechaN.calcularEdad());
        System.out.println("Frecuencia cardiaca máxima:"+frecuenciaC.getMaximaFrecuenciaCardiaca());
        System.out.println("Frecuencia recomendada:"+"["+frecuenciaC.getMaximaFrecuenciaCardiaca()/2.00 +  "," + frecCard.getMaximaFrecuenciaCardiaca()*0.85+"]");
    }
    
    
}
