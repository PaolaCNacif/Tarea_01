
public class FrecuenciaCardiaca {
    private Fecha fechaNacimiento;
    private String nombre;
    
    //Constructor
    
    public void FrecuenciaCardiaca(String nombre, Fecha fecha){
        this.nombre=nombre;
        fechaNacimiento=fecha;
    }
    
    public double getMaximaFrecuenciaCardiaca(){
        double frecuenciaC;
        frecuenciaC= 220- fechaNacimiento.calcularEdad();
        return frecuenciaC;
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public Fecha getFechaNacimiento(){
        return fechaNacimiento;
    }
    
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    
    public void setFechaNacimiento(Fecha fecha){
        fechaNacimiento=fecha;
        
    }
    
}
